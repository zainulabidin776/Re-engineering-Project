package interfaces;


import javax.swing.JFrame;



public class Register {
  public static void main(String[] args)
  {
    
	  Login_Interface loginInterface = new Login_Interface();
	  loginInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	  loginInterface.setVisible(true);
  
  }
}


